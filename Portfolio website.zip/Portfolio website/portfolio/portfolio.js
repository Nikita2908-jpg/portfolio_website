const video1 = document.getElementById('projectvideo1');
const video2 = document.getElementById('projectvideo2');
const video3 = document.getElementById('projectvideo3');
const video4 = document.getElementById('projectvideo4');

// Sidebar
const SideBar = document.querySelector('.sidebar');
const menu = document.querySelector('.menu-icons')
const close = document.querySelector('close-icon')

const videoList = [video1, video2, video3, video4];
videoList.forEach(function (video){
    video.addEventListener('mouseover',function(){
        video.play()
    })
    video.addEventListener('mouseout',function(){
        video.pause()
    })
})


// sidebar
menu.addEventListener('click', function(){
    SideBar.classList.remove('close-sidebar')
    SideBar.classList.add('open-sidebar')
})
close.addEventListener('click',function(){
    SideBar.classList.remove('open-sidebar')
    SideBar.classList.add('close-sidebar')
})

